package com.javarush.telegram;

public enum DialogMode {
    MAIN,
    PROFILE,
    OPENER,
    MESSAGE,
    DATE,
    GPT,
}
